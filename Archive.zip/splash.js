document.addEventListener("DOMContentLoaded", () => {
    // Wait for splash screen animation to finish (3 seconds)
    setTimeout(() => {
    window.location.href = "main.html"; // Replace 'main.html' with your target HTML file
}, 4400); // Match the animation duration in CSS
});
  